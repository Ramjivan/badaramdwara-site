<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Donation</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link href="templatemo_style.css" rel="stylesheet" type="text/css" />
    <link href="css_pirobox/white/style.css" media="screen" title="shadow" rel="stylesheet" type="text/css" />
<script>
   function val() {
	   if(document.getElementById("n").value=="") {
		   alert("please enter your name");
		   document.getElementById("n").focus();
		   return false;
	   }
	   function IsMobileNumber(b) {
			var mob = /^[1-9]{1}[0-9]{9}$/;
			return mob.test(b)
	   }
	   if(document.getElementById("num").value=="") {
		   alert("please enter your contact number");
		   document.getElementById("num").focus();
		   return false;
	   } else {
			var b=document.getElementById("num");
			if(!IsMobileNumber(b.value)) {
				alert(" *please enter correct contact number");
				return false;
			}
		}
	   if(document.getElementById("ad").value=="") {
		   alert("please enter your Address");
		   document.getElementById("ad").focus();
		   return false;
	   }
   }
   </script>
   
    <link href='http://fonts.googleapis.com/css?family=Cantarell|Oswald' rel='stylesheet' type='text/css'>
    <link href="styles.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="nivo/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="nivo/nivo-slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="prettyphoto/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
    <link rel="icon" href="favicon.ico" sizes="16x16" type="image/ico" />
    
    <script type="text/javascript" src="nivo/jquery-1.6.1.min.js"></script>
    <script src="prettyphoto/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="Scripts/script.js"></script>
</head>

<body>

<div id="container"><center><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;" /><img src="images/rm2.png" style="background-image:url(images/banner.gif); border-radius: 7px;" width="732" height="100"/><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;"/></center>
	<div id="header">
        <div id="top">
        <ul class="menu" id="menu">
			<li><div id="header-rss"><p><a href="index.php" class="menulink">Home</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="about.php" id="active" class="menulink">About Us</a></p></div></li>
  		    <li><div class="header-rss"><p><a href="guru.php" id="active" class="menulink">Gurukul</a></p></div></li>
 		    <li><div class="header-rss"><p><a href="goshala.php" id="active" class="menulink">Goshala</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="bhojanshala.php" id="active" class="menulink">Bhojanshala</a></p></div></li>
   			<li><div class="header-rss"><p><a href="index.php" id="active" class="menulink">Gallery</a></p></div>
          	 	<ul>
				<li><a href="video.php">Video Gallery</a></li>
				<li><a href="photo.php" class="sub">Photo Gallery</a></li><li><a href="audiolist.php" class="sub">Audio Gallery</a></li>
				</ul>  
       		</li>
   			<li><div class="header-rss"><p><a href="book.php" id="active" class="menulink" >Books</a></p></div></li>
<li><div class="header-rss"><p><a href="donateform.php" id="active" class="menulink" >Donation</a></p></div></li>
    		<li><div class="header-rss"><p><a href="contact.php" id="active" class="menulink">Contact Us</a></p></div></li>
		</ul>
		</div></div>
        

	<div id="templatemo_content_wrapper" style=" height:auto; width:1000px;">
    <div style="width:600px; height:600px; margin-top:50px;  margin:auto; background-color:rgba(255, 255, 204, .8);margin-bottom:20px;">
         <form method="post" action="" onSubmit="return val();">
                  <div style="width:500px; height:20px; margin-top:20px;"></div>
                   <div style="width:550px; height:20px; margin-top:50px;">
	                   <div style="width:auto; height:auto; float:left; margin-left:100px; color:#000;">Name</div>
                       <div style="width:auto; height:auto; float:left; margin-left:30px;">
                        <input type="text" name="N" value="" size="40" id="n" class="design" />
                       </div>
                   </div>
                      <div class="clear"></div>
                      
                   <div style="width:550px; height:20px; margin-top:50px;">
           	    	   <div style="width:auto; height:auto; float:left; margin-left:100px; color:#000;">Address</div>
            	       <div style="width:auto; height:auto; float:left; margin-left:20px;">
                       	<textarea cols="37" rows="4" name="adde" id="ad"/></textarea>
                       </div>
                      </div>
                      <div class="clear"></div>
                      
                   <div style="width:550px; height:20px; margin-top:50px;">
              	 	  <div style="width:auto; height:auto; float:left; margin-left:95px; color:#000;">Contact</div>
                 	  <div style="width:auto; height:auto; float:left; margin-left:25px;">
                   		<input type="text" name="contact" value=""  size="40" id="num" class="design" />
                   	  </div>
                                                                                                                             
                      </div><div class="clear"></div>
                      
                   <div style="width:550px; height:20px; margin-top:50px;">
                   <div style="width:auto; height:auto; float:left; margin-left:100px; color:#000;">Email</div>
                   <div style="width:auto; height:auto; float:left; margin-left:35px;">
                   	<input type="email" name="mail" value="" size="40" class="design"  />
                   </div>
                                                                                                                             
                     </div><div class="clear"></div>
                      
                   <div style="width:500px; height:20px; margin-top:50px;">
                   <div style="width:auto; height:auto; float:left; margin-left:100px; color:#000;">Message</div>
                   <div style="width:auto; height:auto; float:left; margin-left:20px;">
                   		<textarea name="msg" cols="37" rows="4"></textarea>
                   </div>
                    
                    </div><div class="clear"></div>
                      
                   <div style="width:550px; height:20px; margin-top:50px;">
                   <div style="width:auto; height:auto; float:left; margin-left:100px; color:#000;">Amount</div>
                   <div style="width:auto; height:auto; float:left; margin-left:35px;">
                   		<input type="number" name="amount" value="" size="40" class="design"  />
                   </div>
                                                                                                                            
                      </div><div class="clear"></div><br><br>

                      <div class="pm-button" align="center" style="margin-top:20px;">
                      <a href ="https://www.payumoney.com/paybypayumoney/#/e7bc6049fb94d47c008bf29823605623"> 
                      	<img src="https://www.payumoney.com//media/images/payby_payumoney/buttons/212.png" />
                      </a></div>
				</form>
			</div>
		</div> <!-- end of content -->
	</div>
 
 <style>
 .design { border-radius: 7px; height: 20px; }
 </style>
    
</body>
</html>