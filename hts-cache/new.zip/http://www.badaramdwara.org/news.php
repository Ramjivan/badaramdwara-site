<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>


<body>
<span style="font-size:12px; color:#FF3300;"><center>विशाल श्रीमद् भगवत कथा  महोत्सव</center></span>
<marquee scrollamount="2" width="200px" onmouseover="stop();" onmouseout="start();" style="width:180px; height:180px; font-size:12px;">
<div style="padding:5px;">
				1. श्री रामप्रसाद जी महाराज के जनमोत्सव देव जुलनी एकादशी दिनाँक 13 /09 /2016 को संतो के पावन सान्निध्य मे श्री ठाकुर जी के नोका विहार मनोरथ दर्शन एवम विशाल भजन संध्या का आयोजन | <br>
                
</div>
</marquee>

</body>
</html>
