<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Bada Ram Dwara-Photo Gallery</title>
<link href='http://fonts.googleapis.com/css?family=Cantarell|Oswald' rel='stylesheet' type='text/css'>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="nivo/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="nivo/nivo-slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="prettyphoto/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
<link rel="icon" href="favicon.ico" sizes="16x16" type="image/ico" />
<script type="text/javascript" src="nivo/jquery-1.6.1.min.js"></script>
<script src="prettyphoto/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="Scripts/script.js"></script>

   <script type="text/javascript">
		$(document).ready(function(){
		//Set opacity on each span to 0%
		$(".rollover").css({'opacity':'0'});
		 
		$('#gallery a.item').hover(
			function() {
				$(this).find('.rollover').stop().fadeTo(500, 1);
			},
			function() {
				$(this).find('.rollover').stop().fadeTo(500, 0);
			}
		)
		});
	</script>
   <script src="Scripts/AC_ActiveX.js" type="text/javascript"></script>
   <script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>

<body>
<div id="container"><center><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;" /><img src="images/rm2.png" style="background-image:url(images/banner.gif); border-radius: 7px;" width="732" height="100"/><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;"/></center>
	<!---BEGIN Header--->
	<div id="header">
        <div id="top">
        <ul class="menu" id="menu">
			<li><div class="header-rss"><p><a href="index.php" class="menulink" id="active">Home</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="about.php" id="active" class="menulink">About Us</a></p></div></li>
  		    <li><div class="header-rss"><p><a href="guru.php" id="active" class="menulink">Gurukul</a></p></div></li>
 		    <li><div class="header-rss"><p><a href="goshala.php" id="active" class="menulink">Goshala</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="bhojanshala.php" id="active" class="menulink">Bhojanshala</a></p></div></li>
   			<li><div id="header-rss"><p><a href="index.php" class="menulink">Gallery</a></p></div>
          	 	<ul>
				<li><a href="video.php">Video Gallery</a></li>
				<li><a href="photo.php" class="sub">Photo Gallery</a></li><li><a href="audiolist.php" class="sub">Audio Gallery</a></li>
				</ul>  
       		</li>
   			<li><div class="header-rss"><p><a href="book.php" id="active" class="menulink" >Books</a></p></div></li>
<li><div class="header-rss"><p><a href="donateform.php" id="active" class="menulink" >Donation</a></p></div></li>
    		<li><div class="header-rss"><p><a href="contact.php" id="active" class="menulink">Contact Us</a></p></div></li>
		</ul>
		</div></div>
    <!---BEGIN Slider--->
    <div align="center">
           <object classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000
codebase=http://download.macromedia.com/pub/shockwave/cabs/
flash/swflash.cab#version=5,0,2,0 width=500	height=322>
<param name=movie value=ramji.swf>  <!-- Put your flash file name -->
<param name=quality value=high>
<param name=wmode value=transparent>
<!--<param name=BGCOLOR value=#112B4D>-->
<param name=SCALE value=noborder>
<embed src=ramji.swf quality=high wmode=transparent pluginspage=http://www.macromedia.com/shockwave/download 
/index.cgi?P1_Prod_Version=ShockwaveFlash type=application/x-shockwave-flash
width="940"
height="322";
scale= noborder>
</embed>
</object>
        </div>
        <div id="gallery">
           <div style="width:900px; height:300px;"> <center><div id="title-divider"><h3>Portfolio Gallery</h3></div></center>
            <a href="" style="width:200px;" class="item"><span class=""></span><span class=""></span></a>
            <a href="photo_gallery1.php" class="item"><span class="rollover"></span><span class="gallery-shadow"></span><img src="images/gallery/f3.jpg"/></a>
            <a href="photo_gallery2.php" class="item"><span class="rollover"></span><span class="gallery-shadow"></span><img src="images/gallery/f1.jpg"/></a>
            <a href="photo_gallery3.php" class="item"><span class="rollover"></span><span class="gallery-shadow"></span><img src="images/gallery/f1.jpg"/></a>
            </div>
             </div>
        </div>
</div>
        
<!---BEGIN Footer--->
<div id="footer">
	<div id="footer-container">
    	<div id="footer-flickr">
         <h3>Books</h3>
            <a href="images/books/amulya.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book1.jpg" /></a>
            <a href="images/books/pravachan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book3.jpg" /></a>
            <a href="images/books/arpan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book8.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book4.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book5.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book6.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book7.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book2.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book9.jpg" /></a>
        </div>
        <div id="footer-facebook">
        <h3>Social Networks</h3>
            <div id="fb-comment"><a href="https://www.facebook.com/Badaramdwara-992369254148791/timeline/?ref=aymt_homepage_panel" target="_blank"><img src="images/fb.png" />Connect with us on Facebook </a></div>
            <div id="fb-comment"><a href="http://www.twitter.com" target="_blank"><img src="images/twit.png" />Follow us on Twitter </a></div>
            <div id="fb-comment"><a href="http://www.youtube.com/watch?v=WWFg7Zt9BdM" target="_blank"><img src="images/yt.png" />See videos on Youtube </a></div>
              <center> <div>Design By <a href="http://www.adroitinfocom.com" target="_blank" style="color:#FFFFFF; text-align:center;">Adroit Infocom</a> </div></center>
        </div>
        <div id="footer-tweet">
        	<div id="footer-tweet-container">
            	<h3>News And Events</h3>
                 <iframe src="news.php" name="news" width="210" height="180"></iframe>
                </div>
        </div>
    </div>
</div>
        

    <script type="text/javascript" src="nivo/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider({
			effect:'random', 
            slices:15,  
            animSpeed:500, 
            pauseTime:5000
			});
    });
    </script>
    
    <script type="text/javascript" charset="utf-8">
	$(document).ready(function(){
		$("a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', theme:'dark_rounded', social_tools:false, slideshow:false, autoplay_slideshow: false});
		$(".image a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', theme:'dark_rounded', social_tools:false, slideshow:false, autoplay_slideshow: false});
	});
	</script>
	 <script type="text/javascript">
	var menu=new menu.dd("menu");
	menu.init("menu","menuhover");
</script>
</body>
</html>
