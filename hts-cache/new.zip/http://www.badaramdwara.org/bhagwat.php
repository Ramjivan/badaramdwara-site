<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Bada Ram Dwara-Bhagwat Katha</title>
<link href='http://fonts.googleapis.com/css?family=Cantarell|Oswald' rel='stylesheet' type='text/css'>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="nivo/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="nivo/nivo-slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="prettyphoto/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />

<script type="text/javascript" src="nivo/jquery-1.6.1.min.js"></script>
<script src="prettyphoto/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="Scripts/script.js"></script>

   <script type="text/javascript">
		$(document).ready(function(){
		//Set opacity on each span to 0%
		$(".rollover").css({'opacity':'0'});
		 
		$('#gallery a.item').hover(
			function() {
				$(this).find('.rollover').stop().fadeTo(500, 1);
			},
			function() {
				$(this).find('.rollover').stop().fadeTo(500, 0);
			}
		)
		});
	</script>
   <script src="Scripts/AC_ActiveX.js" type="text/javascript"></script>
   <script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script></head>
<body>
<div id="container"><center><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;" /><img src="images/rm2.png" style="background-image:url(images/banner.gif); border-radius: 7px;" width="732" height="100"/><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;"/></center>
	<!---BEGIN Header--->
	<div id="header">
        <div id="top">
        <ul class="menu" id="menu">
			<li><div class="header-rss"><p><a href="index.php" class="menulink" id="active">Home</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="about.php" id="active" class="menulink">About Us</a></p></div></li>
  		    <li><div class="header-rss"><p><a href="guru.php" id="active" class="menulink">Gurukul</a></p></div></li>
 		    <li><div class="header-rss"><p><a href="goshala.php" id="active" class="menulink">Goshala</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="bhojanshala.php" id="active" class="menulink">Bhojanshala</a></p></div></li>
   			<li><div class="header-rss"><p><a href="index.php" id="active" class="menulink">Gallery</a></p></div>
          	 	<ul>
				<li><a href="video.php">Video Gallery</a></li>
				<li><a href="photo.php" class="sub">Photo Gallery</a></li><li><a href="audiolist.php" class="sub">Audio Gallery</a></li>
				</ul>  
       		    </li>
   		    <li><div class="header-rss"><p><a href="book.php" id="active" class="menulink" >Books</a></p></div></li>
<li><div class="header-rss"><p><a href="donateform.php" id="active" class="menulink" >Donation</a></p></div></li>
    		    <li><div class="header-rss"><p><a href="contact.php" id="active" class="menulink">Contact Us</a></p></div></li>
	</ul>
       </div></div>
    <!---BEGIN Slider--->
        <div id="sub-container" align="center">
      
          <div style="width:940px; background-image:url(images/ramji.jpg); height:auto; background-repeat:no-repeat;" align="center">
   <table width="773" height="694" border="1" style="padding:19px 93px 100px 65px;">
        
  <tr height="30">
    <td height="74" colspan="3"> <p align="center" style="padding-bottom:0px; color:#FFFFFF; text-shadow:#FF0000 3px 3px 3px; font-size:20px; padding-right:115px;">श्रीमद भागवत महापुराण कथा सप्ताह</p></td>
    </tr>
  <tr height="115">
    <td width="142" height="50"><p>प्रथम दिवस</p>
      <p style="color:#990000;">श्रीमद् भागवत महात्मय
एवं शुकदेव परिक्षित चरित्र</p></td>
    <td width="342" height="50">&nbsp;</td>
    <td width="267" height="50"><p>पंचम दिवस</p>
      <p style="color:#990000;"><strong>श्री  कृष्ण बाललीला </strong> <br />
        <strong style="color:#990000;">गोवर्धन  पूजा एवं </strong><br />
        <strong style="color:#990000;">छप्पन  भोग </strong></p></td>
  </tr>
  <tr height="115">
    <td height="60"><p><strong>दितीय</strong> दिवस</p>
      <p><strong style="color:#990000;">श्री  वराहवतार, कपिल </strong><br />
        <strong style="color:#990000;">चरित्र  एवं ध्रुव चरित्र </strong></p></td>
    <td height="60">&nbsp;</td>
    <td height="60"><p><strong>षष्ठी दिवस</strong></p>
      <p><strong style="color:#990000;">श्री  रूकमणि विवाह </strong><br />
       <strong style="color:#990000;">एवं  सुदामा चरित्र </strong></p></td>
  </tr>
  <tr height="115">
    <td height="96"><p>तृतीय दिवस</p>
      <p><strong style="color:#990000;">श्री  प्रहलाद चरित्र,</strong><br />
      <strong style="color:#990000;">नृसिंहावतार </strong></p></td>
    <td height="96">&nbsp;</td>
    <td height="96"><p>सप्तमी दिवस</p>
      <p><strong style="color:#990000;">उद्धव  गीता </strong><br />
       <strong style="color:#990000;">व्यास  पूजन </strong></p></td>
  </tr>
  <tr height="60">
    <td height="60"><p>चतुर्थ दिवस</p>
      <p><strong style="color:#990000;">वामन  चरित्र, रामजन्म </strong><br />
       <strong style="color:#990000;">श्री  कृष्ण जन्मोत्सव </strong><br />
        <strong style="color:#990000;">एवं  नन्दोत्सव </strong></p></td>
    <td height="60"><br /><p align="center" style="color:#FFFFFF; font-size:16px;">विशाल श्रीमद् भगवत कथा </p><br>
      
      
      <p--<p align="center" style="color:#FF0000; font-size:14px;">स्थान:  श्री सूर्यनारायण मंदिर डाली बाई के मंदिर पास चोखा पालबाई  पास  जोधपुर   </p>
      <p align="center" style="color:#FF0000; font-size:14px;">दिनाक : 20 अक्टुम्बर से 26 अक्टुम्बर-2016 </p><br>
      <p align="center" style="color:#FF0000; font-size:14px;">समय : प्रातः 11.30:00 बजे से 4.30बजे तक  </p>
      <! align="center" style="color:#FF0000; font-size:14px;"> :</p>-->
      <p php $getlist = mysql_query("SELECT * FROM latest"); ?>
		 
      
      <!--<p align="center" style="color:#FF0000; font-size:14px;"></p>
      <! align="center" style="color:#FF0000; font-size:12px;"><b style="color:#000;"> </b><br/>
       <br/>

 -->

      </td>
    <td height="60"><br /><br /><p>&nbsp;</p>
      </td>
  </tr>
  <tr><td></td><td><div align="center"><span align="center" style="color:#FFFFFF; font-size:18px;"> </span><span align="center" style="color:#FF0000; font-size:18px;"><br />
</span></div></td><td></td></tr>
</table>
<img src="images/ram.jpg" style="width:600px; height:250px; border:2px solid #000;"  />
</div>
           
           
        </div>
</div>
        
<!---BEGIN Footer--->
<div id="footer">
	<div id="footer-container">
    	<div id="footer-flickr">
        <h3>Books</h3>
            <a href="images/books/amulya.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book1.jpg" /></a>
            <a href="images/books/pravachan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book3.jpg" /></a>
            <a href="images/books/arpan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book8.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book4.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book5.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book6.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book7.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book2.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book9.jpg" /></a>
        </div>
        <div id="footer-facebook">
         <h3>Social Networks</h3>
            <div id="fb-comment"><a href="https://www.facebook.com/Badaramdwara-992369254148791/timeline/?ref=aymt_homepage_panel" target="_blank"><img src="images/fb.png" />Connect with us on Facebook </a></div>
            <div id="fb-comment"><a href="http://www.twitter.com" target="_blank"><img src="images/twit.png" />Follow us on Twitter </a></div>
            <div id="fb-comment"><a href="http://www.youtube.com/watch?v=WWFg7Zt9BdM" target="_blank"><img src="images/yt.png" />See videos on Youtube </a></div>
        </div>
        <div id="footer-tweet">
        	<div id="footer-tweet-container">
            	<h3>News And Events</h3>
                 <iframe src="news.php" name="news" width="210" height="180"></iframe>
                </div>
        </div>
    </div>
</div>
        

    <script type="text/javascript" src="nivo/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider({
			effect:'random', 
            slices:15,  
            animSpeed:500, 
            pauseTime:5000
			});
    });
    </script>
    
    <script type="text/javascript" charset="utf-8">
	$(document).ready(function(){
		$("a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', theme:'dark_rounded', social_tools:false, slideshow:false, autoplay_slideshow: false});
		$(".image a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', theme:'dark_rounded', social_tools:false, slideshow:false, autoplay_slideshow: false});
	});
	</script>
	   <script type="text/javascript">
	var menu=new menu.dd("menu");
	menu.init("menu","menuhover");
</script>
</body>
</html>