<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Bada Ram Dwara-Suvichar</title>
<link href='http://fonts.googleapis.com/css?family=Cantarell|Oswald' rel='stylesheet' type='text/css'>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="nivo/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="nivo/nivo-slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="prettyphoto/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />

<script type="text/javascript" src="nivo/jquery-1.6.1.min.js"></script>
<script src="prettyphoto/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="Scripts/script.js"></script>
   <script type="text/javascript">
		$(document).ready(function(){
		//Set opacity on each span to 0%
		$(".rollover").css({'opacity':'0'});
		 
		$('#gallery a.item').hover(
			function() {
				$(this).find('.rollover').stop().fadeTo(500, 1);
			},
			function() {
				$(this).find('.rollover').stop().fadeTo(500, 0);
			}
		)
		});
	</script>
   <script src="Scripts/AC_ActiveX.js" type="text/javascript"></script>
   <script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>

<body>
<div id="container"><center><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;" /><img src="images/rm2.png" style="background-image:url(images/banner.gif); border-radius: 7px;" width="732" height="100"/><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;"/></center>
	<!---BEGIN Header--->
	<div id="header">
        <div id="top">
        <ul class="menu" id="menu">
			<li><div class="header-rss"><p><a href="index.php" class="menulink" id="active">Home</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="about.php" id="active" class="menulink">About Us</a></p></div></li>
  		    <li><div class="header-rss"><p><a href="guru.php" id="active" class="menulink">Gurukul</a></p></div></li>
 		    <li><div class="header-rss"><p><a href="goshala.php" id="active" class="menulink">Goshala</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="bhojanshala.php" id="active" class="menulink">Bhojanshala</a></p></div></li>
   			<li><div class="header-rss"><p><a href="index.php" id="active" class="menulink">Gallery</a></p></div>
          	 	<ul>
				<li><a href="video.php">Video Gallery</a></li>
				<li><a href="photo.php" class="sub">Photo Gallery</a></li><li><a href="audiolist.php" class="sub">Audio Gallery</a></li>
				</ul>  
       		</li>
   			<li><div class="header-rss"><p><a href="book.php" id="active" class="menulink" >Books</a></p></div></li>
<li><div class="header-rss"><p><a href="donateform.php" id="active" class="menulink" >Donation</a></p></div></li>
    		<li><div class="header-rss"><p><a href="contact.php" id="active" class="menulink">Contact Us</a></p></div></li>
		</ul>
		</div></div>
    <!---BEGIN Slider--->
        <div id="sub-container" align="center">
      <img src="images/snehi.jpg" style="padding-right:20px;" />
          <div style="height:auto;">
        <br /><br />
            
            <div style="border:dashed; width:320px; border-color:#FF0000;"><table width="315" border="1">
  <tr>
    <td width="305" style="font-size:20px"> <div align="center">राम स्नेही समाचार के सदस्य बनकर
      आध्यात्मिक जगत में लाभ प्राप्त करें।</div></td>
  </tr>
  <tr>
    <td> <div align="justify">राम स्नेही समाचार-पत्र के ग्राहक बनकर धार्मिक लेख, संत-महात्माओं के सत्संग-प्रवचन, आदि आचार्यो का वार्षिक उत्सव, आदि कार्यक्रमों की जानकारी के लिए इस समाचार-पत्र को अपने स्थानीय पते पर डाक द्धारा मंगवाकर आध्यात्मिक जगत में लाभ प्राप्त करें एवं अपने संस्थान का विज्ञापन छपवाकर अपने व्यापार को उत्रति प्रदान करें।</div></td>
  </tr>
</table></div><br /><br />
<div style="background-color:#FF6600; border-radius:10px; color:#FFFFFF;">    मों.9352120886   &nbsp;&nbsp; प्रतिः2.50रूपये,    &nbsp;&nbsp;वार्षिकः60रूपये, &nbsp;&nbsp;आजीवनः600/रूपये
</div><br />
            
    
<p style="text-decoration:underline; font-size:16px; background-color:#FFCC99; color:#000;">भोगीशैल परिक्रमा में श्रद्धालुओं का सैलाब उमड़ा</p><br />
<p style="text-decoration:underline; font-size:16px; background-color:#FFCC99; color:#000;">राम स्नेही संत रामप्रसादजी द्धारा परिक्रमा पड़ाव स्थलों पर सत्सगं</p><br />
<p style="text-decoration:underline; font-size:16px; background-color:#FFCC99; color:#000;">चातुर्मास सत्संग के अन्तर्गत, राम स्नेही संत श्री रामप्रसादजी का आगामी कार्यक्रम</p><br />
<p style="text-decoration:underline; font-size:16px; background-color:#FFCC99; color:#000;">बालसंत कृपारामजी महाराज द्धारा राम कथा का भव्य आयोजन</p><br />
<p style="background-color:#FF6600; border-radius:10px; color:#FFFFFF;">स्वत्वाधिकारी सम्पादक, प्रकाशक रूगाराम चैधरी के लिए मुद्रक मधुसुधन लोहिया द्धारा विनय प्रिंटिग एण्ड बाईण्डिंग वक्र्स, बालवाड़ी स्कूल के सामने, जालोरी गेट, जोधपुर से मुद्रित एवं रामस्नेही समाचार कार्यालय 237 जोशी कॉलोनी, चानणा भाखर, जोधपुर से प्रकाशित। फोन 9352120886</p><br /><br />

            </div>
           
           
        </div>
        
        <!---BEGIN Contact Form--->

        
        </div>
</div>
        
<!---BEGIN Footer--->
<div id="footer">
	<div id="footer-container">
    	<div id="footer-flickr">
        <h3>Books</h3>
            <a href="images/books/amulya.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book1.jpg" /></a>
            <a href="images/books/pravachan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book3.jpg" /></a>
            <a href="images/books/arpan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book8.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book4.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book5.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book6.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book7.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book2.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book9.jpg" /></a>
        </div>
        <div id="footer-facebook">
         <h3>Social Networks</h3>
            <div id="fb-comment"><a href="https://www.facebook.com/Badaramdwara-992369254148791/timeline/?ref=aymt_homepage_panel" target="_blank"><img src="images/fb.png" />Connect with us on Facebook </a></div>
            <div id="fb-comment"><a href="http://www.twitter.com" target="_blank"><img src="images/twit.png" />Follow us on Twitter</a> </div>
            <div id="fb-comment"><a href="http://www.youtube.com/watch?v=WWFg7Zt9BdM" target="_blank"><img src="images/yt.png" />See videos on Youtube </a></div>
        </div>
        <div id="footer-tweet">
        	<div id="footer-tweet-container">
            	<h3>News And Events</h3>
                 <iframe src="news.php" name="news" width="210" height="180"></iframe>
                </div>
        </div>
    </div>
</div>
        

    <script type="text/javascript" src="nivo/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider({
			effect:'random', 
            slices:15,  
            animSpeed:500, 
            pauseTime:5000
			});
    });
    </script>
    
    <script type="text/javascript" charset="utf-8">
	$(document).ready(function(){
		$("a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', theme:'dark_rounded', social_tools:false, slideshow:false, autoplay_slideshow: false});
		$(".image a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal', theme:'dark_rounded', social_tools:false, slideshow:false, autoplay_slideshow: false});
	});
	</script>
	 <script type="text/javascript">
	var menu=new menu.dd("menu");
	menu.init("menu","menuhover");
</script>
</body>
</html>
