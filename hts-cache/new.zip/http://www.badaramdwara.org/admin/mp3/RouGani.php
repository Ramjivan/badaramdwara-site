
<html>
<head>
<title>RouGani</title>
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:400,100" rel="stylesheet">
</head>
<style>
body{
   font-family: Josefin Sans, sans-serif;
    background: black;
    color:#ABEFFF;
}
    .loginpage img{
        width: 500px;
        height: 150px;
    }
    .loginpage{
        height: 400px;
        width: 500px;
        border:1px solid;
        border-color:#ABEFFF;
        text-align: center;
        border-radius: 5px;
        margin-top: 100px;
    }
    #pageheading{
        font-size:25px;
        color:#ABEFFF;
        margin-top: 10px;
    }
    .loginpage img{
        width: 500px;
    
    }
    input{
        background: black;
        border-color:#ABEFFF;
        border-radius: 10px;
        margin-top: 10px; 
        padding:5px;
        color: #ABEFFF;
    }
     input:hover{
        background: #ABEFFF;
        color: red;

     }

</style>
<body>
<center>
<div class="loginpage">
    <img src="http://store2.up-00.com/2016-03/145709867377541.jpg" alt="Smevk Logo">
    <div id="pageheading">RouGani Shell</div>
    <form method="post">
        User Name: <input type="text" name="uname" ><br>
        Password :  <input type="password" name="pass" ><br>
       <input type="submit" name="login" value="Login">
 