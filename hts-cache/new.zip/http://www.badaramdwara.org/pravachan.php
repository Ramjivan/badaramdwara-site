<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Bada Ram Dwara-Goshala</title>
<link href='http://fonts.googleapis.com/css?family=Cantarell|Oswald' rel='stylesheet' type='text/css'>
<link href="styles.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="nivo/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="nivo/nivo-slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="prettyphoto/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
<link rel="icon" href="favicon.ico" sizes="16x16" type="image/ico" />
<script type="text/javascript" src="Scripts/script.js"></script>
</head>
<body>
<div id="container"><center><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;" /><img src="images/rm2.png" style="background-image:url(images/banner.gif); border-radius: 7px;" width="732" height="100"/><img src="images/lo.gif" width="105" height="100" style="border-radius: 50px;"/></center>
	<!---BEGIN Header--->
	<div id="header">
        <div id="top">
        <ul class="menu" id="menu">
			<li><div class="header-rss"><p><a href="index.php" class="menulink" id="active">Home</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="about.php" id="active" class="menulink">About Us</a></p></div></li>
  		    <li><div class="header-rss"><p><a href="guru.php" id="active" class="menulink">Gurukul</a></p></div></li>
 		    <li><div class="header-rss"><p><a href="goshala.php" id="active" class="menulink">Goshala</a></p></div></li>
   		    <li><div class="header-rss"><p><a href="bhojanshala.php" id="active" class="menulink">Bhojanshala</a></p></div></li>
   			<li><div class="header-rss"><p><a href="index.php" id="active" class="menulink">Gallery</a></p></div>
          	 	<ul>
				<li><a href="video.php">Video Gallery</a></li>
				<li><a href="photo.php" class="sub">Photo Gallery</a></li><li><a href="audiolist.php" class="sub">Audio Gallery</a></li>
				</ul>  
       		</li>
   			<li><div class="header-rss"><p><a href="book.php" id="active" class="menulink" >Books</a></p></div></li>
<li><div class="header-rss"><p><a href="donateform.php" id="active" class="menulink" >Donation</a></p></div></li>
    		<li><div class="header-rss"><p><a href="contact.php" id="active" class="menulink">Contact Us</a></p></div></li>
		</ul>
		</div></div>
        
        <div id="sub-container">
        <!---BEGIN About Me--->
         <div id="about">
       
            <div id="title-sub-divider" style="width:940px; height:auto;" >
              <h3>Pravachan</h3>
           <!-- Fatch pravachan from dsatabase-->
                  <!--
$res=mysql_query("select * from pravachan");
while($f=mysql_fetch_array($res))
{
$status=$f[3];
if($status==Hide)
{
?>
              <br />
              <p align="center" style="font-size:18px;">Title: echo $f[1]; ?></p>
              Discription:<br />
              <p align="justify">
               echo $f[4];}} ?>-->
              </p>
           <br />
           
           <!-----------manav---------->
                                        <p>Title :भोगिशैल परिचय</p>
          <div align="justify"><br />
          </div>
          <p align="justify">भोग शैल का संक्षिप्त स्वरूप सुनकर शौनकादि ऋषियों ने सूतजी से पूछा- हे सूत जी महाराज ! यह भोग शैल पर्वत कौन है! मरूदेश में कैसे आया? इसकी उत्पत्ति कैसे हुई? विस्तारपूर्वक सारी बातें समझाइये।।१।। सूतजी बोले- हे ऋषियों ! मरूदेश में एक बड़ा भारी नागों का बिल था जिसमें असंख्य नाग रहते थे धीरे धीरे वे पृथ्वी में व्याप्त होने लगे।।२।। ये बड़े कुटिल स्वभाव के थे। मनुष्यों का भक्षण करने लगे। इस तरह प्रजा का क्षय देखकर इन्द्र दुखी हुए।।३।। और हिमालय के पास पहुँचकर कहने लगे। हे पुत्र! मरूदेश में एक महाबिल है।।४।। यहां हजारों नाग बसते हैं वे प्रजा का भक्षण कर रहे हैं तू अपने पुत्र भोग शैल को वहां भेज जिससे वह बिल भरजाय। मैं आज तुम्हारा अतिथि बनकर आया हूँ मेरा काम कर और अपूर्व यश को प्राप्त कर।५। हिमालय ने इन्द्र के वचन स्वीकार कर इन्द्र की पूजा की।।६।। फिर अपने पुत्र को बुलाकर कहने लगे। हे पुत्र! आज तुम्हारे लिये इन्द्र अतिथि बनकर आये हैं।।७।। तू शीघ्र मरूदेश में जाकर बिल को पूर कर दे और अपने देवी देवताओं के साथ वही सुख पूर्वक निवास कर।।८।। पिता के वचन सुनकर भोग शैल कहने लगा। हे तात! मैं मरूदेश में नही जाऊँगा। वहाँ तो कँटीले और फल छाया हीन वृक्ष होते हैं।।९।। न वहाँ सिद्ध पुरूष हैं न गन्धर्व, न देवता हैं न कित्रर। रमणीक तीर्थ और निर्मल नदियाँ कहाँ?।।१॰।। वहां तो पापी और कुटिल मनुष्यों का वास है। इतना ही नही अपितु वहां के पशु पक्षी भी दुष्ट हैं।।११।। इतना होने पर भी एक बात और वह यह हैं कि मेरे पंख तो इन्द्र देव ने काट डाले अब मैं वहाँ कैसे जा सकता हूँ।।१२।। यह सुनकर इन्द्र देव ने कहा- इसकी चिन्ता मत कर। मैं स्वंय तुम्हे वहाँ ले जाऊँगा।।१३।। तुम्हारा आश्रय पाकर तीर्थ और देव मंदिर हो जायेंगे।।१४।। तुम्हारें चारों ओर ऋषि मुनियों के आश्रम बन जायेगें। यहां पर जैसा तुम्हारा प्रभाव हैं, उससे करोड़ो गुना अधिक बढ़ जायेगा।।१५।। यह मेरा आर्शीवाद हैं, वरदान हैं। जो वहां दुराचारी मानव हैं वे तुम्हारे दर्शन से ही पाप मुक्त और सदाचारी हो जायेगे।।१६।। हे पर्वत श्रेष्ठ! तू मेरे साथ शीघ्र वहाँ चल अन्यथा बज्र मारकर तुम्हारे टुकड़े टुकड़े कर डालूँगा।।१७।। सूतजी कहने लगे कि इन्द्र के इस प्रकार वचन सुनकर डरता हुआ भोग शैल शीघ्र �</p>
          <br />
          <br />
                    <p>Title :भोगिशैल माहात्म्य्</p>
          <div align="justify"><br />
          </div>
          <p align="justify">स्वर्ग में पहुँचकर देवराज इन्द्र ने संवर्त के नाम के वायु को बुलाया और आदेश दिया कि मरूस्थल में महानाग बिल के कुछ हिस्से खाली रह गये हैं।।१।। इसलिये तुम शीघ्र वहाँ जाकर बालू से भर दों। इन्द्र की आज्ञा पाकर के संवर्त वायु यहाँ से चलकर मरूस्थल में आया।।२।। और भोग शैल की मजबूती और रक्षा के लिये बालू से बिलों के खड्डों को भर दिया।।३।। इस तरह इन्द्र ने इस भोग शैल की स्थापना की। इस आधार पर मण्डलेश्वर की स्थापना से शिव पार्वती का हमेशा के लिये वास हो गया।(४) चैत्र मास के कृष्ण पक्ष में तो शिव पार्वती निश्चल होंकर यही निवास करते हैं।।५।। इस भोग शैल पर्वत पर सारे तीर्थो का निवास हैं इसलिये वह पर्वत बड़ा पवित्र और उत्तम कहा जाता हैं।।६।। यह पर्वत कामना पूरी करने वाला, मोक्ष देने वाला तथा मनोवांच्छित सिद्धि देने वाला हैं। भोग शैल पर्वत पर जो जो जलाशय हैं।।७।। उनका पानी गंगाजल की तरह पवित्र हैं। हे ऋषियों ! इस प्रकार यह भोग शैल पर्वत परम पावन हैं।।८।। भोग शैल पर विराजमान मण्डलेश्वर का माहात्म्य तो वाणी से परे हैं। फिर भी मैं बताता हूँ।।९।। मण्डलेश्वर की कृपा से भक्त के सारे मनोरथ पूर्ण होते हैं। स्वर्ग, मोक्ष, धन, धान्य, पुत्र प्राप्त होंते हैं।।१॰।। जो जो इच्छा करके भक्ति करता हैं वह मनुष्य थोड़े ही परिश्रम से इन्हे प्राप्त कर लेता हैं।।।११।। देवराज इन्द्र ने मनुष्य के परम शत्रु पापों को देखा साथ में काम, क्रोध, लोभ, मद, मोह, मात्सर्य को भी देखा।।१२।। तो देवराज ने उन्हें एकान्त में आदर पूर्वक बुलाकर कहा। हे पापों ! तुम लोग भोग शैल पर्वत की तरफ कभी मत जाना।।१३।। हे पापों ! चाहें स्त्री हो या पुरूष जो भी भोग शैल के निवासी हैं और मण्डलेश्वर के भक्त हैं वे अथवा कहीं का भी रहने वाला हो जो श्रद्धापूर्वक भोग शैल पर्वत पर मण्डलनाथ सेवा मे जाता हैं, उन्हें कभी भी न छूना।।१४।। वे सारे पाप इन्द्र के सामने पूरी प्रतिज्ञा कर भोग शैल पर्वत को छोड़ चले गये।।१५।। हे ऋषियों! इस तरह यह भोग शैल का आख्यान तुम्हे बताया।।१६।। इसके श्रवण करनें से मनुष्य के सारे पाप नष्ट हो जातंे हैं। मण्डलेश्वर के माहात्म्य को सुननें से काम क्रोधादि दूर होते हैं। जो कोई पुरूष मृतिका के अथवा पाषाण के शिवलिंग की स्थापना भोग शैल पर करके पूजा करता हैं �</p>
          <br />
          <br />
           
          <!-----------manav---------->
        </div>
        </div>
         </div>
 </div></div></div></div>
        
<!---BEGIN Footer--->
<div id="footer">
	<div id="footer-container">
    	<div id="footer-flickr">
         <h3>Books</h3>
            <a href="images/books/amulya.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book1.jpg" /></a>
            <a href="images/books/pravachan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book3.jpg" /></a>
            <a href="images/books/arpan.pdf" target="_blank" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book8.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book4.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book5.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book6.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book7.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book2.jpg" /></a>
            <a href="contact.php" class="flickr-item"><span id="flickr-shadow"></span><img src="images/flickr/book9.jpg" /></a>
        </div>
        <div id="footer-facebook">
         <h3>Social Networks</h3>
            <div id="fb-comment"><a href="https://www.facebook.com/Badaramdwara-992369254148791/timeline/?ref=aymt_homepage_panel" target="_blank"><img src="images/fb.png" />Connect with us on Facebook </a></div>
            <div id="fb-comment"><a href="http://www.twitter.com" target="_blank"><img src="images/twit.png" />Follow us on Twitter </a></div>
            <div id="fb-comment"><a href="http://www.youtube.com/watch?v=WWFg7Zt9BdM" target="_blank"><img src="images/yt.png" />See videos on Youtube </a></div>
             <center> <div>Design By <a href="http://www.adroitinfocom.com" target="_blank" style="color:#FFFFFF; text-align:center;">Adroit Infocom</a> </div></center>
        </div>
        <div id="footer-tweet">
        	<div id="footer-tweet-container">
            	<h3>News And Events</h3>
                 <iframe src="news.php" name="news" width="210" height="180"></iframe>
                </div>
        </div>
    </div>
     <script type="text/javascript">
	var menu=new menu.dd("menu");
	menu.init("menu","menuhover");
</script>
</body>
</html>